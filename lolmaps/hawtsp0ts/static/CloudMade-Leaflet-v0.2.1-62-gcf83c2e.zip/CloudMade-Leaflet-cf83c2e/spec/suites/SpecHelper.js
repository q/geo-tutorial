function noSpecs() {
	xit('should have specs', function() {
		expect('specs').toBe();
	});
}